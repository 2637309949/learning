package com.smart.exception;

public class NotLoginException extends RuntimeException{
	
}
