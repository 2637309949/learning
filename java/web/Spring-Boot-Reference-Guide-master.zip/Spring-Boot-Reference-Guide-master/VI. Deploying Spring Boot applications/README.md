### 部署Spring Boot应用
Spring Boot灵活的打包选项为部署应用提供多种选择，你可以轻易的将Spring Boot应用部署到各种云平台，容器镜像（比如Docker）或虚拟/真实机器。

本章节覆盖一些比较常见的部署场景。
