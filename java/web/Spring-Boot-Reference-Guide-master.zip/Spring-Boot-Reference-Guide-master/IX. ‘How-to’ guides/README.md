### How-to指南

本章节将回答一些常见的"我该怎么做"类型的问题，这些问题在我们使用Spring Boot时经常遇到。这虽然不是一个详尽的列表，但它覆盖了很多方面。

如果遇到一个特殊的我们没有覆盖的问题，你可以查看[stackoverflow.com](http://stackoverflow.com/tags/spring-boot)，看是否已经有人给出了答案；这也是一个很好的提新问题的地方（请使用`spring-boot`标签）。

我们也乐意扩展本章节；如果想添加一个'how-to'，你可以给我们发一个[pull请求](http://github.com/spring-projects/spring-boot/tree/master)。
