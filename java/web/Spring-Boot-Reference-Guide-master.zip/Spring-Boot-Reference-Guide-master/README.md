# Spring-Boot-Reference-Guide
Spring Boot Reference Guide中文翻译 -《Spring Boot参考指南》

说明：本文档翻译的版本：[1.4.1.RELEASE](http://docs.spring.io/spring-boot/docs/1.4.1.RELEASE/reference/htmlsingle/)。

如感兴趣，可以star或fork该[仓库](https://github.com/qibaoguang/Spring-Boot-Reference-Guide)！

Github：[https://github.com/qibaoguang/](https://github.com/qibaoguang/)

GitBook : [Spring Boot参考指南](https://www.gitbook.com/book/qbgbook/spring-boot-reference-guide-zh/details)

整合示例：[程序猿DD-Spring Boot教程](http://git.oschina.net/didispace/SpringBoot-Learning)

Email：qibaoguang@gmail.com

[从这里开始](SUMMARY.md)

交流群：
* spring boot最佳实践2 ： 460560346
* spring boot最佳实践（已满） ：445015546

**注** 1.3版本查看本仓库的release。
