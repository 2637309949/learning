### Spring Boot特性

本章节将深入详细的介绍Spring Boot，通过阅读本节你可以了解到需要使用和定制的核心特性。如果没做好准备，你可以先阅读[Part II. Getting started](http://docs.spring.io/spring-boot/docs/1.4.1.RELEASE/reference/htmlsingle/#getting-started)和[Part III, “Using Spring Boot” ](http://docs.spring.io/spring-boot/docs/1.4.1.RELEASE/reference/htmlsingle/#using-boot)章节，以对Spring Boot有个良好的基本认识。
