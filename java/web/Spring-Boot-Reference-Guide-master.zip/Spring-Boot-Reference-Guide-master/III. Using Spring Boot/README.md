### 使用Spring Boot
本章节将详细介绍如何使用Spring Boot，不仅覆盖构建系统，自动配置，如何运行应用等主题，还包括一些Spring Boot的最佳实践。尽管Spring Boot本身没有什么特别的（跟其他一样，它只是另一个你可以使用的库），但仍有一些建议，如果遵循的话将会事半功倍。

如果你刚接触Spring Boot，那最好先阅读上一章节的[Getting Started](../II. Getting started/README.md)指南。
